<!DOCTYPE html>

<html>
	<head>
		<meta charset="UTF-8">
			<link rel="stylesheet" type="text/css" href="./styles/admin.css" media="all" />
		</head>

		<body>
			<form name="admin" action="membre.php" method="post">
				<fieldset>
					<legend><strong><h3>Erreur!</h3></strong></legend>
					<h4 style="text-align:center;">
					Vous devez être connécté pour pouvoir accéder à ce contenu!
					</h4>
					<p style="text-align:center;"	>
						<input class="button" type="submit" value="Redirection"> 
						</p>				
					</fieldset>  
				</form>
			</body>
		</html>
		